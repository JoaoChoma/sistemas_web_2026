# Atividade — Interface Web do TERMO

Conteúdo do pacote:

- `atividade_termo.md`: enunciado completo da atividade.
- `imagens/referencia_interface_termo.png`: referência visual utilizada no Markdown.

O Markdown usa caminho relativo para a imagem. Portanto, mantenha a pasta `imagens` ao lado do arquivo `.md` ao publicar no GitHub ou distribuir aos alunos.
